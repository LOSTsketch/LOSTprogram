<?php

define('EMAIL','v.el.2second.class@gmail.com');
define('PASSWORD','ragnarok55');

define('DB_HOST','localhost');
define('DB_USER', 'id12823784_root');
define('DB_PASS', 'Vailem2020');
define('DB_NAME', 'id12823784_vailemdb');