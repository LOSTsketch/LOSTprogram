<?php require_once 'controllers/authController.php'; ?>
<!DOCTYPE html>
<html lang="pt_br">
    <head>
       
       <meta charset="utf-8">
       <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
       
       <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    
        <!-- CSS --> 
        <link rel="stylesheet" href="MOD.css">
        
        <title>VAILEM</title>
        
    </head>
    <body>

            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand mb-0 h1" href="index.php">VAILEM</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite" aria-controls="navbarSite" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

        <div class="collapse navbar-collapse" id="navbarSite">
            <ul class="navbar-nav mr-auto ">
              <li class="nav-item">
                <a class="nav-link" href="#" data-toggle="modal" data-target="#Login">Login</a>  
              </li>
              
               <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Biblioteca
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="#curso1">Curso1</a>
                  <a class="dropdown-item" href="#curso2">Curso2</a>
                </div>
              </li>
              
                <li class="nav-item">
                <a class="nav-link" href="#sobre">Sobre</a>
              </li>
              
            </ul>
            
            <form class="form-inline my-2 my-lg-0">
              <input class="form-control mr-sm-2" type="search" placeholder="Pesquisa" aria-label="Search">
              <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Pesquisar</button>
            </form>
        </div>
            </nav>
        
        <div class=" container flex-forms">
           <div class="section-header text-center mt-3 mb-0">
              <h1 class="display-4 font-weight-bold">Cadastro</h1>
              <hr class="divider">
           </div>
        </div>
           
           <div class="container">

           <form action="Cadastro.php" method="POST">

           <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <?php foreach($errors as $error): ?>
                            <li><?php echo $error; ?><li>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

           <form>
               <div class="form-row justify-content-center">
                   <div class="col-md-4">
                       <div class="form-group">
                           <label for="username">Nome</label>
                           <input type="text" name="username" id="username" value="<?php echo $username; ?>" class="form-control">
                       </div>   
                   </div>
                    <div class="col-md-4">
                       <div class="form-group">
                           <label for="lastname">Sobrenome</label>
                           <input type="text" name="lastname" value="<?php echo $lastname; ?>" id="lastname" class="form-control">
                       </div>   
                   </div>
                </div>
                 <div class="form-row justify-content-center">
                     <div class="col-md-2">
                         <div class="form-group">
                             <label for="date">Data de Nascimento</label>
                             <input type="int" name="date" value="<?php echo $date; ?>" id="date" class="form-control">
                         </div>
                     </div>
                     <div class="col-md-6">
                         <div class="form-group">
                             <label for="address">Endereço</label>
                             <input type="text" name="address" value="<?php echo $address; ?>" id="address" class="form-control">
                         </div>
                     </div>
                 </div>
                  <div class="form-row justify-content-center">
                      <div class="col-md-2">
                          <div class="form-group">
                              <label for="state">Estado</label>
                              <input type="text" name="state" value="<?php echo $state; ?>" id="state" class="form-control">
                          </div>
                      </div>
                      <div class="col-md-4">
                          <div class="form-group">
                              <label for="city">Cidade</label>
                              <input type="text" name="city" value="<?php echo $city; ?>" id="city" class="form-control">
                          </div>
                      </div>
                      <div class="col-md-2">
                          <div class="form-group">
                              <label for="cep">CEP</label>
                              <input type="text" name="cep" value="<?php echo $cep; ?>" id="cep" class="form-control">
                          </div>
                      </div>
                  </div>
                   <div class="form-row justify-content-center">
                    <div class="col-md-8">
                             <div class="form-group">
                              <label for="complement">Complemento</label>
                              <input type="text" name="complement" value="<?php echo $complement; ?>" id="complement" class="form-control">
                              </div>
                        </div>
               </div>
                     
                      <div class="form-row justify-content-center">
                          <div class="col-md-2">
                             <div class="form-group">
                              <label for="number">Telefone/Celular</label>
                              <input type="text" name="number" value="<?php echo $number; ?>" id="number" class="form-control">
                              </div>
                          </div>
                          <div class="col-md-6">
                             <div class="form-group">
                              <label for="cpf">CPF</label>
                              <input type="text" name="cpf" value="<?php echo $cpf; ?>" id="cpf" class="form-control">
                          </div>
                          </div>
                      </div>
                      
                      <div class="form-row justify-content-center">
                          <div class="col-md-4">
                             <div class="form-group">
                       <label for="email">E-mail</label>
                       <input type="text" name="email" id="email" value="<?php echo $email; ?>" class="form-control">
                   </div>
                              
                          </div>
                          <div class="col-md-4">
                             <div class="form-group">
                       <label for="emailconf">Confirmar E-email</label>
                       <input type="text" name="emailconf" id="emailconf" class="form-control">
                   </div>
                              
                          </div>
                      </div>
                      <div class="form-row justify-content-center">
                <div class="col-md-4">      
                   <div class="form-group">
                       <label for="password">Senha</label>
                       <input type="password" name="password" id="password" class="form-control">
                   </div>
               </div>
                  <div class="col-md-4">
                   <div class="form-group">
                       <label for="passwordconf">Confirma Senha</label>
                       <input type="password" name="passwordconf" id="passwordconf" class="form-control">
                   </div>
                          </div>
               </div>
                  <div class="form-row justify-content-center">
                  <div class="col-md-8">
                   <div class="form-group">
                       <label for="university">Faculdade(Opcional)</label>
                       <input type="text" name="university" value="<?php echo $university; ?>" id="university" class="form-control">
                   </div>
                      </div>
               </div>
                   <div class="form-row justify-content-center">
                   <div class="col-md-8">
                   <div class="form-group">
                       <label for="forma-pagamento">Forma de Pagamento</label>
                       <select class="form-control" id="forma-pagamento">
                           <option>Cartão de Credito</option>
                           <option>Boleto Bancario</option>
                           <option>PicPay</option>
                           <option>Paypal</option>
                           <option>Codigo do Professor</option>
                       </select>
                   </div>
                       </div>
               </div>
                   <br>
                   <div class="row justify-content-around">
                       <div class="col-auto mr-4">
                           <a href="index.php" type="button" class="btn btn-secondary">Voltar</a>
                       </div>
                       <div class="col-auto">
                       <div class="form-group">
                           <button type="submit" name="b-cadastrar" class="btn btn-dark">Cadastrar</button>
                       </div>
               </div>
                   
           </form>
           
            
        </div>
        
        <footer class="container flex-forms">
           <hr class="divider">
           <div class="section-header text-center mt-3 mb-0">
              <p class="display-5">Acervo de livros Universitarios VAILEM</p>
           </div>
            
            
        </footer>
        
        <div class="row">
                    <div class="col-md-12">
           
                       <div class="modal fade" id="Login">
                           <div class="modal-dialog">
                            <div class="modal-content">
                               <div class="modal-header">
                                   <h1>Login</h1>
                               </div>
                               <div class="modal-body">
                                   <form action="" style="width: 350px; margin: auto">
                                      <div class="form-group">
                                       <label for="email">E-mail</label>
                                       <input type="text" name="email" id="email" class="form-control">
                                       <small id="esqueceu-senha" class="form-text">
                                           <a href="#">Esqueceu o Email?</a>
                                       </small>
                                       </div>
                                       <div class="form-group">
                                       <label for="password">Senha</label>
                                       <input type="password" name="senha" id="senha" class="form-control">
                                       <small id="esqueceu-senha" class="form-text">
                                           <a href="#">Esqueceu a Senha?</a>
                                       </small>
                                       </div>
                                       <div class="form-check">
                                           <input type="checkbox" class="form-check-input" id="lembrar">
                                           <label class="form-check-label" for="lembrar">Lembrar Usuario</label>
                                       </div>
                                   </form>
                               </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Voltar</button>
                                   <input  type="submit" class="btn btn-dark" value="Entrar">
                                </div>
                            </div>
                           </div>
                        </div>
                    </div>
                </div>
        
        
        
        
        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    
    </body>
</html>