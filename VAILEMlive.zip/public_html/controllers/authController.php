<?php 

session_start();

require 'config/db.php';
require_once 'emailController.php';

$errors = array();
$username = "";
$lastname = "";
$email = "";
$state = "";
$date = "";
$cep = "";
$city = "";
$complement = "";
$cpf = "";
$number = "";
$university = "";
$address = "";



if (isset($_POST['b-cadastrar'])){
    $username = $_POST['username'];
    $lastname = $_POST['lastname'];
    $date = $_POST['date'];
    $state = $_POST['state'];
    $city = $_POST['city'];
    $cep = $_POST['cep'];
    $complement = $_POST['complement'];
    $number = $_POST['number'];
    $university = $_POST['university'];
    $email = $_POST['email'];
    $emailconf = $_POST['emailconf'];
    $password = $_POST['password'];
    $passwordconf = $_POST['passwordconf'];
    $address = $_POST['address'];
    $cpf = $_POST['cpf'];
    
    //Confirmacao de campos no cadastro

    if (empty($username)){
        $errors['username'] = "Requer usuario";
    }
    if (empty($lastname)){
        $errors['lastname'] = "Requer sobrenome";
    }
    if (empty($date)){
        $errors['date'] = "Requer data";
    }
    if (empty($state)){
        $errors['state'] = "Requer estado";
    }
    if (empty($city)){
        $errors['city'] = "Requer cidade";
    }
    if (empty($cep)){
        $errors['cep'] = "Requer cep";
    }
    if (empty($complement)){
        $errors['complement'] = "Requer complemento";
    }
    if (empty($number)){
        $errors['number'] = "Requer numero do celular";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $errors['email'] = "E-mail invalido";
    }
    if (empty($email)){
        $errors['email'] = "Requer e-mail";
    }
    if ($email !== $emailconf){
        $errors['email'] = "Os e-mails nao sao identicos";
    }
    if (empty($password)){
        $errors['password'] = "Requer senha";
    }
    if ($password !== $passwordconf){
        $errors['password'] = "As senhas nao sao identicas";
    }
    if (empty($cpf)){
        $errors['cpf'] = "Requer CPF";
    }

    $emailQuery = "SELECT * FROM `vl_cadastro` WHERE email=? LIMIT 1";
    $stmt = $conn->prepare($emailQuery);
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $userCountE = $result->num_rows;
    $stmt->close();
    
    $cpfQuery = "SELECT * FROM `vl_cadastro` WHERE cpf=? LIMIT 1";
    $stmt = $conn->prepare($cpfQuery);
    $stmt->bind_param('s', $cpf);
    $stmt->execute();
    $result = $stmt->get_result();
    $userCountC = $result->num_rows;
    $stmt->close();

    if ($userCountE > 0){
        $errors['email'] = "E-mail ja cadastrado";
    }

    if ($userCountC > 0){
        $errors['cpf'] = "CPF ja cadastrado";
    }

    if (count($errors) === 0){
        $password = password_hash($password, PASSWORD_DEFAULT);
        $token = bin2hex(random_bytes(50));
        $verified = false;

        $sql = "INSERT INTO `vl_cadastro` (username, lastname, date, address, state, city, cep, complement, number, cpf, email, password, university, token, verified) VALUE(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";  
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ssisssisiissssb', $username, $lastname, $date, $address, $state, $city, $cep, $complement, $number, $cpf, $email, $password, $university, $token, $verified);
        
        if ($stmt->execute()){

            $user_id = $conn->insert_id;
            $_SESSION['id'] = $user_id;
            $_SESSION['cpf'] = $cpf;
            $_SESSION['username'] = $username;
            $_SESSION['email'] = $email;
            $_SESSION['verified'] = $verified;

            sendVerificationEmail($email, $token);
            
            $_SESSION['message'] = "Voce esta conectado!";
            $_SESSION['alert-class'] = "alert-success";

            header('location: index.php');
            exit();
        }
        else{
            $errors['db_error'] = "Database error: failed to register";
        }
    }
}

if (isset($_POST['b-entrar'])){
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpf = $_POST['cpf'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $errors['email'] = "E-mail invalido";
    }
    if (empty($email)){
        $errors['email'] = "Requer e-mail";
    }
    if (empty($password)){
        $errors['password'] = "Requer senha";
    }
    if (empty($cpf)){
        $errors['cpf'] = "Requer CPF";
    }

    if(count($errors) === 0){

        $emailQuery = "SELECT * FROM `vl_cadastro` WHERE email=? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if(password_verify($password, $user['password'])){

        $_SESSION['id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['verified'] = $user['verified'];
            
        $_SESSION['message'] = "Voce esta conectado!";
        $_SESSION['alert-class'] = "alert-success";

        header('location: indexLogado.php');
        exit();

    }else{
        $errors['login_fail'] = "credenciais erradas";
    }
    }
}


if(isset($_GET['logout'])){
    session_destroy();
    unset($_SESSION['id']);
    unset($_SESSION['username']);
    unset($_SESSION['cpf']);
    unset($_SESSION['email']);
    unset($_SESSION['verify']);
    header('location: index.php');
    exit();
}

function verifyUser($token)
{
    global $conn;
    $sql = "SELECT * FROM `vl_cadastro` WHERE token='$token' LIMIT 1 ";
    $result = mysqli_query($conn, $sql);


    if (mysqli_num_rows($result) > 0){
        $user = mysqli_fetch_assoc($result);
        $update_query = "UPDATE `vl_cadastro` SET verified=1 WHERE token='$token'";

        if(mysqli_query($conn, $update_query)){

            $_SESSION['id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['verified'] = 1;
                
            $_SESSION['message'] = "Seu Email foi verificado com sucesso!";
            $_SESSION['alert-class'] = "alert-success";
    
            header('location: index.php');
            exit();

        }
    }
    else {

        echo 'User not found';
        
    }
}
