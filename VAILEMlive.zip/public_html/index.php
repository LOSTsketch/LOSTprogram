<!DOCTYPE html>
<html lang="pt_br">
    <head>
       
       <meta charset="utf-8">
       <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
       
       <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    
        <!-- CSS --> 
        <link rel="stylesheet" href="MOD.css">
        
        <title>VAILEM</title>
        
    </head>
    <body>
        
        <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand mb-0 h1" href="index.php">VAILEM</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite" aria-controls="navbarSite" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

        <div class="collapse navbar-collapse" id="navbarSite">
            <ul class="navbar-nav nav nav-pills mr-auto">
              <li class="nav-item">
                <a class="nav-link" href="#" data-toggle="modal" data-target="#Login">Login</a>  
              </li>
              
              <li class="nav-item">
                <a class="nav-link" href="Cadastro.php">Cadastro</a>
              </li>
              
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Biblioteca
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="#curso1">Administração</a>
                  <a class="dropdown-item" href="#curso2">Negócios</a>
                </div>
              </li>
                <li class="nav-item">
                <a class="nav-link" href="#sobre">Sobre</a>
              </li>
              
            </ul>
            
            <form class="form-inline my-2 my-lg-0">
              <input class="form-control mr-sm-2" type="search" placeholder="Buscar..." aria-label="Search">
              <button class="btn btn-outline-info my-2 my-sm-0" type="submit">Pesquisar</button>
            </form>
        </div>
            </nav>
            
        <div id="carouselSite" class="carousel slide" data-ride="carousel">
         
         
            <ol class="carousel-indicators">
                
                <li data-target="#carouselSite" data-slide-to="0" class="active"></li>
                <li data-target="#carouselSite" data-slide-to="1"></li>
                
            </ol>  
            <div class="carousel-inner">
               
                <div class="carousel-item active">
                    <img src="img/64857.jpg" class="img-fluid d-block">
                    <div class="carousel-caption bg-dark rounded">
                        <h3 class="text-uppercase">Ainda não é cadastrado!</h3>
                        <p>Faça já seu cadastro, é rapido e fácil</p>
                        <a class="btn btn-success" href="Cadastro.php" role="button">Cadastre-se</a>   
                    </div>
                </div>
                 <div class="carousel-item">
                    <img src="img/64857.jpg" class="img-fluid d-block">
                     <div class="carousel-caption bg-dark rounded">
                        <h3 class="text-uppercase">Confira nosso Acervo</h3>
                        <p>Livros disponiveis nos Cursos de Administração e Negócios</p>
                        <a class="btn btn-success" href="Biblioteca.php" role="button">Biblioteca</a>   
                    </div>
                </div>
                  
            </div>
            
            <a class="carousel-control-prev" href="#carouselSite" role="button" data-slide="prev">
                
                <span class="carousel-control-prev-icon"></span>
                <span class="sr-only">Anterior</span>
                
            </a>
            <a class="carousel-control-next" href="#carouselSite" role="button" data-slide="next">
                
                <span class="carousel-control-next-icon"></span>
                <span class="sr-only">Avançar</span>
                
            </a>
            
        </div>  
           
           
           
        <div class="container">
          
           <div class="row">
              <div class="col-12 text-center my-3">
                  
                  <h1 id="biblioteca" class="display-4 text-uppercase">Livros disponiveis</h1>
                  <p>Livros mais visualizados por curso da biblioteca</p>
                  <hr class="divider">
                  
              </div>
               
           </div>
           
           <div class="row d-flex justify-content-center flex-wrap mb-1" >
              
              <div class="card-deck">
                  <div class="card text-center" style="width: 13rem;">
                     
                      <img class="card-img-top" src="img/livro1.jpg" alt="Capa livro1">
                      <div class="card-body">
                          <h5 class="card-title">Desenhando Quadrinhos</h5>
                      </div>
                      <div class="card-footer">
                        
                         <a href="#" class="btn btn-dark">Ler</a>
                          
                      </div>  
                      
                  </div>
                  
                     <div class="card text-center" style="width: 13rem;">
                     
                      <img class="card-img-top" src="img/livro2.jpg" alt="Capa livro1">
                      <div class="card-body">
                          <h5 class="card-title">Desvendando Quadrinhos</h5>
                      </div>
                      <div class="card-footer">
                          <a href="#" class="btn btn-dark">Ler</a>
                      </div>  
                      
                  </div>
                  
                     <div class="card text-center" style="width: 13rem;">
                     
                      <img class="card-img-top" src="img/livro3.png" alt="Capa livro1">
                      <div class="card-body">
                          <h5 class="card-title">Planos de Negocios</h5>
                      </div>
                      <div class="card-footer">
                          <a href="#" class="btn btn-dark">Ler</a>
                      </div>  
                      
                  </div>
                  
                     <div class="card text-center" style="width: 13rem;">
                     
                      <img class="card-img-top" src="img/livro5.png" alt="Capa livro1">
                      <div class="card-body">
                          <h5 class="card-title">Force Dynamic Drawing</h5>
                      </div>  
                      <div class="card-footer">
                          <a href="#" class="btn btn-dark">Ler</a>
                      </div>
                      
                  </div>
                  
               </div>
               
               <div class="col-12 text-center my-4">
               
               <a href="Biblioteca.php" class="btn btn-dark">Ver mais</a>
               <hr class="divider">
               
               </div>
            </div>
            
            <div class="row">
              <div class="col-12 text-center my-2">
                  
                  <h1 id="curso1" class="display-4 text-uppercase">Administração</h1>
                  <p>Livros mais visualizados em Administração</p>
                  <hr class="divider">
                  
              </div>
               
           </div>
           
           <div class="row d-flex justify-content-center flex-wrap mb-1" >
              
              <div class="card-deck">
                  <div class="card text-center" style="width: 13rem;">
                     
                      <img class="card-img-top" src="img/livro1.jpg" alt="Capa livro1">
                      <div class="card-body">
                          <h5 class="card-title">Desenhando Quadrinhos</h5>
                      </div>
                      <div class="card-footer">
                        
                         <a href="#" class="btn btn-dark">Ler</a>
                          
                      </div>  
                      
                  </div>
                  
                     <div class="card text-center" style="width: 13rem;">
                     
                      <img class="card-img-top" src="img/livro2.jpg" alt="Capa livro1">
                      <div class="card-body">
                          <h5 class="card-title">Desvendando Quadrinhos</h5>
                      </div>
                      <div class="card-footer">
                          <a href="#" class="btn btn-dark">Ler</a>
                      </div>  
                      
                  </div>
                  
                     <div class="card text-center" style="width: 13rem;">
                     
                      <img class="card-img-top" src="img/livro3.png" alt="Capa livro1">
                      <div class="card-body">
                          <h5 class="card-title">Planos de Negocios</h5>
                      </div>
                      <div class="card-footer">
                          <a href="#" class="btn btn-dark">Ler</a>
                      </div>  
                      
                  </div>
                  
                     <div class="card text-center" style="width: 13rem;">
                     
                      <img class="card-img-top" src="img/livro5.png" alt="Capa livro1">
                      <div class="card-body">
                          <h5 class="card-title">Force Dynamic Drawing</h5>
                      </div>  
                      <div class="card-footer">
                          <a href="#" class="btn btn-dark">Ler</a>
                      </div>
                      
                  </div>
                  
               </div>
               
               <div class="col-12 text-center my-4">
               
               <a href="Curso1.php" class="btn btn-dark">Ver mais</a>
               <hr class="divider">
               
               </div>
            </div>
            
            <div class="row">
              <div class="col-12 text-center my-2">
                  
                  <h1 id="curso2" class="display-4 text-uppercase">Negócios</h1>
                  <p>Livros mais visualizados em Negócios</p>
                  <hr class="divider">
                  
              </div>
               
           </div>
           
           <div class="row d-flex justify-content-center flex-wrap mb-1" >
              
              <div class="card-deck">
                  <div class="card text-center" style="width: 13rem;">
                     
                      <img class="card-img-top" src="img/livro1.jpg" alt="Capa livro1">
                      <div class="card-body">
                          <h5 class="card-title">Desenhando Quadrinhos</h5>
                      </div>
                      <div class="card-footer">
                        
                         <a href="#" class="btn btn-dark">Ler</a>
                          
                      </div>  
                      
                  </div>
                  
                     <div class="card text-center" style="width: 13rem;">
                     
                      <img class="card-img-top" src="img/livro2.jpg" alt="Capa livro1">
                      <div class="card-body">
                          <h5 class="card-title">Desvendando Quadrinhos</h5>
                      </div>
                      <div class="card-footer">
                          <a href="#" class="btn btn-dark">Ler</a>
                      </div>  
                      
                  </div>
                  
                     <div class="card text-center" style="width: 13rem;">
                     
                      <img class="card-img-top" src="img/livro3.png" alt="Capa livro1">
                      <div class="card-body">
                          <h5 class="card-title">Planos de Negocios</h5>
                      </div>
                      <div class="card-footer">
                          <a href="#" class="btn btn-dark">Ler</a>
                      </div>  
                      
                  </div>
                  
                     <div class="card text-center" style="width: 13rem;">
                     
                      <img class="card-img-top" src="img/livro5.png" alt="Capa livro1">
                      <div class="card-body">
                          <h5 class="card-title">Force Dynamic Drawing</h5>
                      </div>  
                      <div class="card-footer">
                          <a href="#" class="btn btn-dark">Ler</a>
                      </div>
                      
                  </div>
                  
               </div>
               
               <div class="col-12 text-center my-4">
               
               <a href="Curso2.php" class="btn btn-dark">Ver mais</a>
               <hr class="divider">
               
               </div>
            </div>
            
            <div class="row">
                <div class="col-12 text-center my-2">
                    <h1 id="sobre" class="display-4 text-uppercase">Sobre a VAILEM</h1>
                    <hr class="divider">
                </div>
            </div>
            
            <div class="row">
                <div class="col-3">
                   <div class="nav flex-column nav-pills" id="NavSobre-tab" role="tablist" aria-orientation="vertical">
                       
                       <a class="nav-link active" id="NavSobre-sobre-tab" data-toggle="pill" href="#item1" role="tab" aria-controls="item1" aria-selectec="true">Sobre</a>
                       <a class="nav-link" id="NavSobre-equipe-tab" data-toggle="pill" href="#item2" role="tab" aria-controls="item2" aria-selectec="false">Equipe</a>
                       <a class="nav-link" id="NavSobre-tutorial-tab" data-toggle="pill" href="#item3" role="tab" aria-controls="item3" aria-selectec="false">Como Ultilizar</a>
                       <a class="nav-link" id="NavSobre-sac-tab" data-toggle="pill" href="#item4" role="tab" aria-controls="item4" aria-selectec="false">SAC</a>
                       
                       </div>
                       
                   </div>
                    
                <div class="col-9">
                    <div class="tab-content" id="NavSobre-tabContent">
                        <div class="tab-pane fade show active" id="item1" role="tabpanel" aria-labelledby="NavSobre-sobre-tab"> A Vailem é uma empresa que surgiu do cansaço universitário. Sim! 
                            <br>
                            Cansamos de ter que procurar livros durante horas, cansamos de ter que pagar caro para poder utilizá-los, 
                            cansamos de não encontrar a obra que precisávamos na biblioteca porque alguém emprestou e resolveu que iria ficar com o livro.
                            <br>
                            A Vailem veio para acabar com isso, encontre todos os livros que você precisa, na palma da sua mão, sem ter que vender sua alma para pagar por isso.
                            <br>
                            Baixe já o Vailem!
                            <br>
                            Facilite sua vida no uso dos livros acadêmicos. Assine agora ou crie uma conta com 7 dias gratiutos.
                        </div>
                        
                        <div class="tab-pane fade" id="item2" role="tabpanel" aria-labelledby="NavSobre-equipe-tab">Equipe Vailem
                        <br>
                        Gabriel:
                        <br>
                        Thiago:
                        <br>
                        Suely:
                        <br>
                        Lauriano:
                        </div>
                        
                          <div class="tab-pane fade" id="item3" role="tabpanel" aria-labelledby="NavSobre-tutorial-tab">Vídeo Tutorial
                        </div>
                        
                          <div class="tab-pane fade" id="item4" role="tabpanel" aria-labelledby="NavSobre-SAC-tab">Teve algum problema ? Reporte para nós através destes canais:
                          <br>
                          Email: vailemstartup@outlook.com
                          <br>
                          Telefone: (92) 98137-7926
                        </div>
                    </div>
                
                
            </div>
            
        </div>
        </div>
                 
                 
                 
      <footer class="container flex-forms">
           <hr class="divider">
           <div class="section-header text-center mt-3 mb-0">
              <p class="display-5">Acervo de livros Universitarios VAILEM</p>
           </div>
            </footer>
                  
        
                   
            
            
        
        
        
        <div class="row">
                    <div class="col-md-12">
           
                       <div class="modal fade" id="Login">
                           <div class="modal-dialog">
                            <div class="modal-content">
                               <div class="modal-header">
                                   <h1>Login</h1>
                               </div>
                               <div class="modal-body">
                                   <form action="" style="width: 350px; margin: auto">
                                      <div class="form-group">
                                       <label for="email">E-mail</label>
                                       <input type="text" name="email" id="email" class="form-control">
                                       <small id="esqueceu-senha" class="form-text">
                                           <a href="#">Esqueceu o Email?</a>
                                       </small>
                                       </div>
                                       <div class="form-group">
                                       <label for="password">Senha</label>
                                       <input type="password" name="senha" id="senha" class="form-control">
                                       <small id="esqueceu-senha" class="form-text">
                                           <a href="#">Esqueceu a Senha?</a>
                                       </small>
                                       </div>
                                       <div class="form-check">
                                           <input type="checkbox" class="form-check-input" id="lembrar">
                                           <label class="form-check-label" for="lembrar">Lembrar Usuario</label>
                                       </div>
                                   </form>
                               </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Voltar</button>
                                   <input  type="submit" class="btn btn-dark" value="Entrar">
                                </div>
                            </div>
                           </div>
                        </div>
                    </div>
                </div>
        
        
        
        
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        
       
        
        
    </body>
    
</html>